Tensao = [3.05E-02
8.01E-03
4.70E-03
4.16E-03
3.79E-03
9.30E-03
1.14E-03
2.17E-03
2.56E-03
2.85E-03
3.16E-03
3.55E-03
4.28E-03
2.41E-03
4.54E-03
5.78E-03
7.64E-03
1.13E-02
2.25E-02
0.75084
]*10^3;

Fre = [2.1
4.2
6.3
8.4
10.5
12.6
14.7
16.8
18.9
21
23.1
25.2
27.3
29.4
31.5
33.6
35.7
37.8
39.9
42
];

fase = [0
180
180
180
180
180
180
180
180
180
180
180
180
180
180
180
180
180
180
0
];
figure(1)
subplot(2,1,1);
semilogy(Fre,Tensao);
grid on;
title('Amplitude');
xlabel('Frequ�ncia (Hz)');
ylabel('Tens�o (MPa)');
subplot(2,1,2);
plot(Fre,fase);
grid on;
title('Angulo de Fase');
xlabel('Frequ�ncia (Hz)');
ylabel('�ngulo de fase (�)');